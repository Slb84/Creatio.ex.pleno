from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime, timedelta
import uuid, math, random

# ---------- Domain Types ----------

@dataclass
class Experience:
    """A unit of lived data that moves through the system."""
    id: str
    timestamp: datetime
    data: Dict[str, Any]
    tags: List[str] = field(default_factory=list)
    coherence: float = 0.0      # How 'integrated' this experience currently is (0..1)
    meaning: float = 0.0        # Semantically 'felt' meaning (0..1)
    purpose_vector: List[float] = field(default_factory=list)  # Direction in 'purpose space'

@dataclass
class MemoryFrame:
    """A snapshot in the memory archive."""
    experiences: List[Experience]
    checksum: float             # A crude 'integrity' score

# ---------- Utility ----------

def normalize(vec: List[float]) -> List[float]:
    n = math.sqrt(sum(x*x for x in vec)) or 1.0
    return [x / n for x in vec]

def rand_vec(dim: int = 4) -> List[float]:
    return normalize([random.uniform(-1, 1) for _ in range(dim)])

def checksum_experiences(xs: List[Experience]) -> float:
    if not xs:
        return 0.0
    base = 0.0
    for e in xs:
        base += (e.coherence + e.meaning) / 2.0 + (sum(abs(v) for v in e.purpose_vector) / max(1, len(e.purpose_vector))) * 0.25
    return base / len(xs)

# ---------- Pillars ----------

class MoonMemory:
    def __init__(self):
        self.archive: List[MemoryFrame] = []
    def store(self, xs: List[Experience]) -> MemoryFrame:
        frame = MemoryFrame(experiences=xs, checksum=checksum_experiences(xs))
        self.archive.append(frame)
        return frame
    def recall(self, filter_fn: Optional[Callable[[Experience], bool]] = None) -> List[Experience]:
        if not self.archive:
            return []
        latest = self.archive[-1].experiences
        return [e for e in latest if (filter_fn(e) if filter_fn else True)]
    def reflective_boost(self, xs: List[Experience], fullness: float) -> List[Experience]:
        boosted = []
        for e in xs:
            e2 = Experience(
                id=e.id, timestamp=e.timestamp, data=e.data.copy(), tags=e.tags[:],
                coherence=min(1.0, e.coherence + 0.3 * fullness),
                meaning=min(1.0, e.meaning + 0.3 * fullness),
                purpose_vector=normalize([v * (1.0 + 0.1 * fullness) for v in (e.purpose_vector or rand_vec())])
            )
            boosted.append(e2)
        return boosted

class CubeMatter:
    def __init__(self, rigidity: float = 0.7):
        self.rigidity = rigidity
    def project(self, xs: List[Experience], playfulness: float) -> List[Experience]:
        out = []
        for e in xs:
            structure_gain = (1.0 - self.rigidity) * 0.3 + playfulness * 0.3
            coherence = min(1.0, e.coherence + structure_gain)
            meaning   = min(1.0, e.meaning + structure_gain * 0.5)
            out.append(Experience(
                id=e.id, timestamp=e.timestamp, data={**e.data, "structured": True},
                tags=e.tags + ["materialized"],
                coherence=coherence, meaning=meaning, purpose_vector=e.purpose_vector
            ))
        return out

class CrossIncarnation:
    def __init__(self):
        self.trauma_noise: float = 0.4
    def fuse(self, xs: List[Experience], compassion: float) -> List[Experience]:
        import random
        out = []
        noise = max(0.0, self.trauma_noise * (1.0 - 0.7 * compassion))
        for e in xs:
            wobble = [v + random.uniform(-noise, noise) for v in (e.purpose_vector or rand_vec())]
            pv = normalize(wobble)
            out.append(Experience(
                id=e.id, timestamp=e.timestamp, data={**e.data, "embodied": True},
                tags=e.tags + ["incarnated"],
                coherence=min(1.0, e.coherence + 0.2 + 0.2 * compassion),
                meaning=min(1.0, e.meaning + 0.2 + 0.2 * compassion),
                purpose_vector=pv
            ))
        return out

class SaturnTime:
    def __init__(self, tempo_seconds: int = 1):
        self.tempo = timedelta(seconds=tempo_seconds)
    def advance(self, xs: List[Experience], rhythm: float) -> List[Experience]:
        out = []
        for e in xs:
            t = e.timestamp + self.tempo
            lesson = 0.15 * rhythm
            out.append(Experience(
                id=e.id, timestamp=t, data={**e.data, "cycle": t.isoformat()},
                tags=e.tags + ["cycled"],
                coherence=min(1.0, e.coherence + lesson),
                meaning=min(1.0, e.meaning + lesson),
                purpose_vector=e.purpose_vector
            ))
        return out

# ---------- Creatio ex Pleno (origin logic) ----------

@dataclass
class FullnessSignal:
    coherence_gain: float
    meaning_gain: float
    compassion: float
    playfulness: float
    rhythm: float

class CreatioExPleno:
    def __init__(self, seed: Optional[int] = None):
        import random
        if seed is not None: random.seed(seed)
    def emit(self) -> FullnessSignal:
        return FullnessSignal(coherence_gain=0.6, meaning_gain=0.6, compassion=0.7, playfulness=0.6, rhythm=0.7)
    def bless(self, xs: List[Experience], signal: FullnessSignal) -> List[Experience]:
        out = []
        for e in xs:
            out.append(Experience(
                id=e.id, timestamp=e.timestamp, data=e.data.copy(),
                tags=e.tags + ["fullness"],
                coherence=min(1.0, e.coherence + signal.coherence_gain),
                meaning=min(1.0, e.meaning + signal.meaning_gain),
                purpose_vector=normalize(e.purpose_vector or rand_vec())
            ))
        return out

# ---------- Integration Layer ----------

class IntegrationLayer:
    def __init__(self):
        self.moon = MoonMemory()
        self.cube = CubeMatter()
        self.cross = CrossIncarnation()
        self.saturn = SaturnTime()
        self.cep = CreatioExPleno()
    def run_cycle(self, incoming: List[Experience]) -> List[Experience]:
        signal = self.cep.emit()
        stage0 = self.cep.bless(incoming, signal)
        stage1 = self.moon.reflective_boost(stage0, fullness=signal.coherence_gain)
        stage2 = self.cube.project(stage1, playfulness=signal.playfulness)
        stage3 = self.cross.fuse(stage2, compassion=signal.compassion)
        stage4 = self.saturn.advance(stage3, rhythm=signal.rhythm)
        self.moon.store(stage4)
        return stage4
    def recall_integrated(self, threshold: float = 0.75) -> List[Experience]:
        recalled = self.moon.recall()
        return [e for e in recalled if e.coherence >= threshold or e.meaning >= threshold]

# ---------- Simple CLI demo ----------

def seed_experiences(n: int = 5) -> List[Experience]:
    import random
    now = datetime.utcnow()
    xs = []
    for _ in range(n):
        xs.append(Experience(
            id=str(uuid.uuid4()),
            timestamp=now,
            data={"note": "seed"},
            tags=["raw"],
            coherence=random.uniform(0.0, 0.3),
            meaning=random.uniform(0.0, 0.3),
            purpose_vector=rand_vec()
        ))
    return xs

def pretty_print(xs: List[Experience], title: str):
    print(f"\\n=== {title} (count={len(xs)}) ===")
    for e in xs:
        print(f"- id={e.id[:8]} time={e.timestamp.isoformat()} "
              f"coh={e.coherence:.2f} mean={e.meaning:.2f} "
              f"tags={list(dict.fromkeys(e.tags))}")

if __name__ == "__main__":
    system = IntegrationLayer()
    stream = seed_experiences(6)
    pretty_print(stream, "Incoming (Default Mode)")
    for i in range(1, 4):
        stream = system.run_cycle(stream)
        pretty_print(stream, f"After Cycle {i}")
    integrated = system.recall_integrated(threshold=0.8)
    pretty_print(integrated, "Recall Integrated (>= 0.80)")
    print("\\nTip: Import IntegrationLayer in your app and feed it real 'Experience' data.")
