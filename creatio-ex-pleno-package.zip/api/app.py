from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
from code.creatio_ex_pleno import Experience, IntegrationLayer

app = FastAPI(title="Creatio ex Pleno API", version="1.0.0")
system = IntegrationLayer()

class ExperienceIn(BaseModel):
    id: Optional[str] = None
    timestamp: Optional[datetime] = None
    data: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    coherence: float = 0.0
    meaning: float = 0.0
    purpose_vector: List[float] = Field(default_factory=list)

class ExperienceOut(BaseModel):
    id: str
    timestamp: datetime
    data: Dict[str, Any]
    tags: List[str]
    coherence: float
    meaning: float
    purpose_vector: List[float]

@app.get("/health")
def health():
    return {"status": "ok", "message": "Creatio ex Pleno API is running."}

@app.post("/run_cycle", response_model=List[ExperienceOut])
def run_cycle(items: List[ExperienceIn]):
    # Convert input into domain objects (fill defaults)
    incoming: List[Experience] = []
    now = datetime.utcnow()
    import uuid
    for it in items:
        incoming.append(Experience(
            id = it.id or str(uuid.uuid4()),
            timestamp = it.timestamp or now,
            data = it.data,
            tags = it.tags or ["raw"],
            coherence = it.coherence,
            meaning = it.meaning,
            purpose_vector = it.purpose_vector or []
        ))
    # Run system
    out = system.run_cycle(incoming)
    # Serialize
    return [ExperienceOut(
        id=e.id, timestamp=e.timestamp, data=e.data, tags=e.tags,
        coherence=e.coherence, meaning=e.meaning, purpose_vector=e.purpose_vector
    ) for e in out]
