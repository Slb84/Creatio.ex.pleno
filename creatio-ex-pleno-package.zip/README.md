# Creatio ex Pleno — Integration Layer
**Creation from Fullness** expressed as a small, runnable system that integrates the symbolic pillars — **Moon (Memory)**, **Cube (Matter)**, **Cross (Incarnation)**, **Saturn (Time)** — through a missing **Integration Layer**.

This repo includes:
- `code/creatio_ex_pleno.py` — Core mini-OS (no external deps).
- `api/app.py` — FastAPI wrapper exposing `/run_cycle`.
- `notebooks/Creatio_ex_Plено_Colab.ipynb` — Ready-to-run Colab notebook.
- `docs/creatio_ex_pleno_manifesto.pdf` — Illustrated manifesto.
- `diagrams/` — PNG diagrams used in the manifesto.
- `requirements.txt` — API deps.

## Quick Run (CLI)
```bash
python code/creatio_ex_pleno.py
```

## Run the API (FastAPI + Uvicorn)
```bash
pip install -r requirements.txt
uvicorn api.app:app --reload --port 8000
```
Open: `http://127.0.0.1:8000/health`

### Example request
```bash
curl -X POST http://127.0.0.1:8000/run_cycle \
  -H "Content-Type: application/json" \
  -d '[{
    "data": {"type":"ad","client":"The Grill","message":"Fine dine & unwind"},
    "tags": ["raw"],
    "coherence": 0.2,
    "meaning": 0.1
  }]'
```

## Philosophy ↔ Technology Reconciliation
- **Fullness Signal** (Creatio ex Pleno) re-parameters the system from lack → wholeness.
- **Outputs** return not only numbers (coherence/meaning) but tags showing the journey: `fullness → materialized → incarnated → cycled`.
- Use this as a **decision compass** in ads, community projects, and writing.

## Colab
Open the notebook and run cells top-to-bottom. Replace the example items with your own; export CSV from the last cell.

_Last packaged: 2025-09-10T06:15:52.115230Z_
